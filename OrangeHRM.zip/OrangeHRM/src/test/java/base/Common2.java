package base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class Common2 {
	
	public WebDriver d;
	
	@Parameters("browser")
	@BeforeMethod
	public void launchBrowser(String browser) throws InterruptedException {
		if(browser.equals("CH")) {
			System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\webDrivers\\chromedriver.exe");
			ChromeOptions copt=new ChromeOptions();
			copt.addArguments("--remote-allow-origins=*");
			d=new ChromeDriver(copt);
		}
		else if(browser.equals("FF")) {
			System.setProperty("webdriver.gecko.driver", "D:\\Drivers\\webDrivers\\geckodriver.exe");
			FirefoxOptions fopt=new FirefoxOptions();
			fopt.addArguments("--remote-allow-origins=*");
			d=new FirefoxDriver(fopt);
		}
		else if(browser.equals("ED")) {
			System.setProperty("webdriver.edge.driver", "D:\\Drivers\\webDrivers\\msedgedriver.exe");
			EdgeOptions eopt=new EdgeOptions();
			eopt.addArguments("--remote-allow-origins=*");
			d=new EdgeDriver(eopt);
		}
		
		d.manage().window().maximize();
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		d.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(2000);
	}
	@AfterMethod
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(2000);
		d.quit();
	}

}
